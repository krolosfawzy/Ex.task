export class UserDetail {
    ID:number;
    Name:String;
    IsActive:boolean;
    IsDeleted:boolean;
}

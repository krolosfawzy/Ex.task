import { Injectable } from '@angular/core';
import { UserDetail } from 'src/app/shared/user-detail';
import {HttpClient}from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class UserDetaillService {
  formData:UserDetail;
  listuser:UserDetail[];
  readonly rootURL="http://localhost:54277/api/";
  constructor(private server:HttpClient) { }
  PostUser(formData:UserDetail)
  {
   return this.server.post(`${this.rootURL}Users`,formData);
  }
  GetUser()
  {
   return this.server.get(`${this.rootURL}Users`)
   .toPromise()
   .then(res=>this.listuser=res as UserDetail[]);
  }
  UpdateUser(formData:UserDetail)
  {
   return this.server.put(`${this.rootURL}Users/${this.formData.ID}`,formData);
  }
  DeleteUser(ID:number)
  {
   return this.server.delete(`${this.rootURL}Users/${ID}`);
  }
}

import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UserDetail } from 'src/app/shared/user-detail';
import { UserDetaillService } from 'src/app/shared/user-detaill.service';
@Component({
  selector: 'app-user-detail-list',
  templateUrl: './user-detail-list.component.html',
  styleUrls: ['./user-detail-list.component.css']
})
export class UserDetailListComponent implements OnInit {

  constructor(protected service: UserDetaillService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.GetUser();
  }
  populateForm(user: UserDetail) {
    this.service.formData = Object.assign({}, user);
  }
  onDelete(id: number) {
    if (confirm("Are you sure to delete this record?")) {
      this.service.DeleteUser(id)
      .subscribe(
        res => {
          this.service.GetUser();
          this.toastr.warning("Deleted Done", "User Details");
        },
        err => {
          console.log(err);
        });
    }
  }
}

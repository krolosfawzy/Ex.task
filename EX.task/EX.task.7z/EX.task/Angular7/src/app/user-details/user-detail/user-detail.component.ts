import { Component, OnInit } from '@angular/core';
import { UserDetaillService } from 'src/app/shared/user-detaill.service';
import { NgForm } from '@angular/forms';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';
import { UserDetail } from 'src/app/shared/user-detail';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  constructor(protected service: UserDetaillService, private toastr: ToastrService) { }

  ngOnInit() {
    this.resetform();
  }
  resetform(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData =
      {
        ID: 0,
        Name: "",
        IsActive: false,
        IsDeleted: false
      }

  }
  userdata: UserDetail;

  onSubmit(form: NgForm) {
    console.log(this.service.listuser);
    if (this.service.formData.ID == 0) {
      this.userdata = form.value;
      this.userdata.IsActive = this.service.formData.IsActive;
      this.userdata.ID = 0;
      this.userdata.IsDeleted = false;
      this.service.PostUser(this.userdata).subscribe(
        res => {
          this.resetform(form);
          this.service.GetUser();
          this.toastr.success('Add Done', 'User Details');
        },
        err => {
          console.log(err);
        }
      );
    }
    else{
      this.userdata = form.value;
      this.userdata.IsActive = this.service.formData.IsActive;
      this.userdata.IsDeleted = false;
      this.userdata.ID=this.service.formData.ID;
      this.service.UpdateUser(this.userdata).subscribe(
        res => {
          this.resetform(form);
          this.service.GetUser();
          this.toastr.info('Updated Done', 'User Details');
        },
        err => {
          console.log(err);
        }
      );
    }
    console.log("/////////////////" + JSON.stringify(this.userdata));
  }

}

﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Models;
using Repository;

namespace taske.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly IMapper _mapper;
        private readonly IAdminRepository _repository;

        public AdminController(IConfiguration config,
            IMapper mapper,
            IAdminRepository repository)
        {
            _mapper = mapper;
            _config = config;
            _repository = repository;
        }


        // POST api/values
        [Route("register")]
        [HttpPost]
        public async Task<IActionResult> PostRegister(AdminDTO AdminDTO)
        {
            var userToCreate = _mapper.Map<Admin>(AdminDTO);

            var result = await _repository.Register(userToCreate, AdminDTO.Password);

            if (result != null)
            {
                var userToReturn = _mapper.Map<AdminDTO>(result);
                return Ok(userToReturn);
            }
            return BadRequest();
        }

        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> PostLogin(AdminDTO AdminDTO)
        {
            var appUser = await _repository.ValidateAdmin(AdminDTO);

            if(appUser != null)
            {
                var accesstoken = _repository.GenerateJwtToken(appUser, _config.GetSection("AppSettings:Token").Value).Result;
                return Ok(new
                {
                    token = accesstoken
                });
            }
            
            return Unauthorized();
        }
    }
}

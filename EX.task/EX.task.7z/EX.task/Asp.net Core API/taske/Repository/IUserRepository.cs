﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Repository
{
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllUsers();
        Task<User> GetUser(int id);
        Task<bool> RegisterNewUser(User user);
        Task<User> EditUser(int id, User user);
        Task<bool> DeleteUser(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _db;

        public UserRepository(AppDbContext DBcontext)
        {
            _db = DBcontext;
        }
        public async Task<IEnumerable<User>> GetAllUsers()
        {
            var sdvs=  await _db.Users.ToListAsync();
            return sdvs;
        }
        public async Task<User> GetUser(int id)
        {
            return await _db.Users.FindAsync(id);
        }
        public async Task<bool> RegisterNewUser(User user)
        {
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<User> EditUser(int id, User user)
        {
            var realuser = new User();
            if (user != null)
            {
                realuser = await _db.Users.FindAsync(id);
                if (realuser != null)
                {
                    realuser.IsActive = user.IsActive;
                    realuser.Name = user.Name;
                    await _db.SaveChangesAsync();
                }
            }
            return realuser;
        }

        public async Task<bool> DeleteUser(int id)
        {
            var user = await _db.Users.FindAsync(id);
            try
            {
                _db.Users.Remove(user);
                await _db.SaveChangesAsync();
                return true;
            }
            catch { }
            return false;
        }

    }
}
